package com.otaliastudios.cameraview.controls;

import android.content.Context;
import android.content.res.TypedArray;

import androidx.annotation.NonNull;

import com.otaliastudios.cameraview.R;

/**
 * Parses controls from XML attributes.
 */
public class ControlParser {
    private int facing;
    private int flash;
    private int whiteBalance;

    public ControlParser(@NonNull Context context, @NonNull TypedArray array) {
        facing = array.getInteger(R.styleable.CameraView_cameraFacing,
                Facing.DEFAULT(context).value());
        flash = array.getInteger(R.styleable.CameraView_cameraFlash, Flash.DEFAULT.value());
        whiteBalance = array.getInteger(R.styleable.CameraView_cameraWhiteBalance,
                WhiteBalance.DEFAULT.value());
    }

    @NonNull
    public Facing getFacing() {
        //noinspection ConstantConditions
        return Facing.fromValue(facing);
    }

    @NonNull
    public Flash getFlash() {
        return Flash.fromValue(flash);
    }

    @NonNull
    public WhiteBalance getWhiteBalance() {
        return WhiteBalance.fromValue(whiteBalance);
    }
}
