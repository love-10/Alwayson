package com.otaliastudios.cameraview.demo

import android.graphics.Color
import android.graphics.ImageFormat
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.ViewGroup.LayoutParams.MATCH_PARENT

import com.otaliastudios.cameraview.CameraOptions
import com.otaliastudios.cameraview.CameraView
import com.otaliastudios.cameraview.gesture.GestureAction
import kotlin.math.roundToInt
import kotlin.reflect.KClass

/**
 * Controls that we want to display in a ControlView.
 */
abstract class Option<T: Any>(val name: String) {

    abstract fun get(view: CameraView): T

    abstract fun getAll(view: CameraView, options: CameraOptions): Collection<T>

    abstract fun set(view: CameraView, value: T)

    open fun toString(value: T): String {
        return "$value".replace("_", "_").toLowerCase()
    }

    class Width : Option<Int>("Width") {
        override fun get(view: CameraView) = view.layoutParams.width

        override fun set(view: CameraView, value: Int) {
            view.layoutParams.width = value
            view.layoutParams = view.layoutParams
        }

        override fun getAll(view: CameraView, options: CameraOptions): Collection<Int> {
            val root = view.parent as View
            val boundary = root.width.takeIf { it > 0 } ?: 1000
            val step = boundary / 10
            val list = mutableListOf(WRAP_CONTENT, MATCH_PARENT)
            for (i in step until boundary step step) { list.add(i) }
            return list
        }

        override fun toString(value: Int): String {
            if (value == MATCH_PARENT) return "match parent"
            if (value == WRAP_CONTENT) return "wrap content"
            return super.toString(value)
        }
    }

    class Height : Option<Int>("Height") {
        override fun get(view: CameraView) = view.layoutParams.height

        override fun set(view: CameraView, value: Int) {
            view.layoutParams.height = value
            view.layoutParams = view.layoutParams
        }

        override fun getAll(view: CameraView, options: CameraOptions): Collection<Int> {
            val root = view.parent as View
            val boundary = root.height.takeIf { it > 0 } ?: 1000
            val step = boundary / 10
            val list = mutableListOf(WRAP_CONTENT, MATCH_PARENT)
            for (i in step until boundary step step) { list.add(i) }
            return list
        }

        override fun toString(value: Int): String {
            if (value == MATCH_PARENT) return "match parent"
            if (value == WRAP_CONTENT) return "wrap content"
            return super.toString(value)
        }
    }

    abstract class Control<T: com.otaliastudios.cameraview.controls.Control>(private val kclass: KClass<T>, name: String) : Option<T>(name) {
        override fun set(view: CameraView, value: T) = view.set(value)
        override fun get(view: CameraView) = view.get(kclass.java)
        override fun getAll(view: CameraView, options: CameraOptions)
                = options.getSupportedControls(kclass.java)
    }

    class Flash : Control<com.otaliastudios.cameraview.controls.Flash>(com.otaliastudios.cameraview.controls.Flash::class, "Flash")

    class WhiteBalance : Control<com.otaliastudios.cameraview.controls.WhiteBalance>(com.otaliastudios.cameraview.controls.WhiteBalance::class, "White Balance")

    abstract class Gesture(val gesture: com.otaliastudios.cameraview.gesture.Gesture, name: String) : Option<GestureAction>(name) {
        override fun set(view: CameraView, value: GestureAction) {
            view.mapGesture(gesture, value)
        }

        override fun get(view: CameraView): GestureAction {
            return view.getGestureAction(gesture)
        }

        override fun getAll(view: CameraView, options: CameraOptions): Collection<GestureAction> {
            return GestureAction.values().filter {
                gesture.isAssignableTo(it) && options.supports(it)
            }
        }
    }

    class Pinch : Gesture(com.otaliastudios.cameraview.gesture.Gesture.PINCH, "Pinch")

    class VerticalScroll : Gesture(com.otaliastudios.cameraview.gesture.Gesture.SCROLL_VERTICAL, "Vertical Scroll")

    class Tap : Gesture(com.otaliastudios.cameraview.gesture.Gesture.TAP, "Tap")

    class UseDeviceOrientation : Option<Boolean>("Use Device Orientation") {
        override fun getAll(view: CameraView, options: CameraOptions) = listOf(true, false)
        override fun get(view: CameraView) = view.useDeviceOrientation
        override fun set(view: CameraView, value: Boolean) {
            view.useDeviceOrientation = value
        }
    }

    class PreviewFrameRate : Option<Int>("Preview FPS") {
        override fun get(view: CameraView) = view.previewFrameRate.roundToInt()

        override fun set(view: CameraView, value: Int) {
            view.previewFrameRate = value.toFloat()
        }

        override fun getAll(view: CameraView, options: CameraOptions): Collection<Int> {
            val min = options.previewFrameRateMinValue
            val max = options.previewFrameRateMaxValue
            val delta = max - min
            return when {
                min == 0F && max == 0F -> listOf()
                delta < 0.005F -> listOf(min.roundToInt())
                else -> {
                    val results = mutableListOf<Int>()
                    var value = min
                    for (i in 0 until 3) {
                        results.add(value.roundToInt())
                        value += delta / 3
                    }
                    results
                }
            }
        }
    }
}
